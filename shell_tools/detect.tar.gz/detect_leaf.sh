#!/bin/bash

bin_name="goral_leaf_main"

info=`ps -ef | grep $bin_name | grep -v "grep" | wc -l`
ip=`ifconfig |grep "inet addr" |head -n 1|awk '{print $2}'|awk -F: '{print $2}'`

if [ $info -eq 1 ];
then
  echo "$bin_name is OK"
  exit 0
else
  echo "$bin_name crashed in ip:$ip"
  exit 2
fi
